document.getElementById('present-form').addEventListener('submit', function (e) {
    e.preventDefault();

    const nome = document.getElementById('nome').value;
    const valor = document.getElementById('valor').value;
    const imagemInput = document.getElementById('imagem');
    const link = document.getElementById('link').value;

    const li = document.createElement('li');
    li.innerHTML = `
        ${imagemInput.files[0] ? `<img src="" alt="${nome}" width="50" height="50" data-file="${imagemInput.files[0].name}">` : ''}
        <strong>${nome}</strong> - R$ ${valor} 
        <a href="${link}" target="_blank">Comprar</a>
        <button class="remover">Remover</button>
    `;

    document.getElementById('presentes-list').appendChild(li);

    // Lê a imagem, se houver
    if (imagemInput.files[0]) {
        const reader = new FileReader();
        reader.onload = function (event) {
            li.querySelector('img').src = event.target.result;
        };
        reader.readAsDataURL(imagemInput.files[0]);
    }

    // Adiciona o evento de remover
    li.querySelector('.remover').addEventListener('click', function () {
        li.remove();
    });

    document.getElementById('present-form').reset();
});


